package com.javalec.ex;

import java.util.ArrayList;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		AbstractApplicationContext ctx=new GenericXmlApplicationContext("classpath:appCTX.xml");
		//stuInfo->ArrayList(Student)
		StuInfo stuInfo=ctx.getBean("stuInfo",StuInfo.class);
		ArrayList<Student> list=stuInfo.getList();
		StuScore stuScore=ctx.getBean("stuScore3",StuScore.class);
		
		for(int i=0; i<list.size();i++){
			Student stu=list.get(i);
			if(stuScore.stu_num==stu.stu_num) {
				System.out.println("<<"+stu.name+"학생 성적 출력>>");
				System.out.println(stu.stu_num+" ");
				System.out.println(stu.name+" ");
				System.out.println(stu.major+" ");
				System.out.println(stu.address+" ");
				System.out.println(stu.tel+" ");
				System.out.println(stuScore.kor+"");
				System.out.println(stuScore.eng+"");
				System.out.println(stuScore.math+"");
				System.out.println(stuScore.total+"");
				System.out.println(stuScore.avg+"");
				
				
				
			}
		}

	}

}
