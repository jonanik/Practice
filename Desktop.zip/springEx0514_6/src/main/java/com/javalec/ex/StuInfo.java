package com.javalec.ex;

import java.util.ArrayList;

public class StuInfo {

	ArrayList<Student> stuInfo=new ArrayList<Student>();

	public ArrayList<Student> getStuInfo() {
		return stuInfo;
	}

	public void setStuInfo(ArrayList<Student> stuInfo) {
		this.stuInfo = stuInfo;
	}
	public void printList() {
	for(int i=0; i<stuInfo.size();i++) {
		Student student=stuInfo.get(i);
		System.out.println(student.hakNum);
		System.out.println(student.hakName);
		System.out.println(student.hakMajor);
		System.out.println(student.hakAddress);
		System.out.println(student.hakPhone);
	}
	}
}
