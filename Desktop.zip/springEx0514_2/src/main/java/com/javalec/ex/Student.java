package com.javalec.ex;

import java.util.ArrayList;

public class Student {

	private String name;//생성자로 값 주입
	private int age;//생성자로 값 주입
	private ArrayList<String> hobbys; //생성자로 값 주입
	private double height;//setter로 값 주입
	private double weight;//setter로 값 주입
	
	public Student() {}
	public Student(String name,int age,ArrayList<String> hobbys) {
		this.name=name;
		this.age=age;
		this.hobbys=hobbys;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public ArrayList<String> getHobbys() {
		return hobbys;
	}
	public double getHeight() {
		return height;
	}
	public double getWeight() {
		return weight;
	}
	public void setAge(int age) {
		this.age = age;
	}

	public void setHobbys(ArrayList<String> hobbys) {
		this.hobbys = hobbys;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}
	
}
