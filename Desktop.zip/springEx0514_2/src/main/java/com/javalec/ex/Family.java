package com.javalec.ex;

public class Family {

	String fatherName;
	String motherName;
	String sisterName;
	String brotherName;
	
	public Family() {}
	public Family(String fatherName,String motherName) {
		this.fatherName=fatherName;
		this.motherName=motherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}
	public void setSisterName(String sisterName) {
		this.sisterName = sisterName;
	}
	public void setBrotherName(String brotherName) {
		this.brotherName = brotherName;
	}
	
}
