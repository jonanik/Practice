package com.javalec.ex;

import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
	GenericXmlApplicationContext ctx=new GenericXmlApplicationContext();
	ctx.load("appCTX.xml");
	ctx.refresh();
	
	Info info=ctx.getBean("info",Info.class);
	System.out.println("Line: "+info.getLine());
	System.out.println("statn_nm: "+info.getStatn_nm());	
	System.out.println("adres: "+info.getAdres());
	System.out.println("rdnmadr: "+info.getRdnmadr());
	System.out.println("telno: "+info.getTelno());
	
	ctx.close();
	

	}

}
