package com.javalec.ex;

public class Student {

	Student(){}
	Student(String hakNum,String hakName,String hakMajor,String hakAddress,String hakPhone ){
		this.hakNum=hakNum;
		this.hakName=hakName;
		this.hakMajor=hakMajor;
		this.hakAddress=hakAddress;
		this.hakPhone=hakPhone;
	}
	
	String hakNum;
	String hakName;
	String hakMajor;
	String hakAddress;
	String hakPhone;
	
	
	public String getHakNum() {
		return hakNum;
	}
	public void setHakNum(String hakNum) {
		this.hakNum = hakNum;
	}
	public String getHakName() {
		return hakName;
	}
	public void setHakName(String hakName) {
		this.hakName = hakName;
	}
	public String getHakMajor() {
		return hakMajor;
	}
	public void setHakMajor(String hakMajor) {
		this.hakMajor = hakMajor;
	}
	public String getHakAddress() {
		return hakAddress;
	}
	public void setHakAddress(String hakAddress) {
		this.hakAddress = hakAddress;
	}
	public String getHakPhone() {
		return hakPhone;
	}
	public void setHakPhone(String hakPhone) {
		this.hakPhone = hakPhone;
	}
	
	
	
}
