package com.javalec.ex.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javalec.ex.model.service.BService;

@Controller
public class BController {

	@Autowired
	BService bService;

	@RequestMapping("list")
	public String list(Model model) {
		model.addAttribute("list", bService.list());
		return "list";
	}

	@RequestMapping("content_view")
	public String content_view(int bId, Model model) {

		model.addAttribute("content_view", bService.content_view(bId));
		return "content_view";
	}
}
