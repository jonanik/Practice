package com.javelec.ex;

public class Taxi implements Car {

	public void run() {
		System.out.println("시속 250km!!!!!!!!");
		
	}

	public void stop() {
		System.out.println("빨리 멈춤!!!");
		
	}

	public void use() {
		System.out.println("미터기!!!");
	
	}

}
