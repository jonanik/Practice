package com.javalec.ex;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		AbstractApplicationContext ctx=new GenericXmlApplicationContext("appCTX.xml");
		StuInfo stuInfo=ctx.getBean("stuInfo",StuInfo.class);
//		StuScore stuScore=ctx.getBean("stuScore",StuScore.class);
		stuInfo.printList();

	}

}
