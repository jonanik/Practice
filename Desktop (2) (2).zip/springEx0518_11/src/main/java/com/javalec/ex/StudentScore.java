package com.javalec.ex;

public class StudentScore {

	private String hakNum;
	private int kor,eng,math,total;
	private double avg;
	public String getHakNum() {
		return hakNum;
	}
	public void setHakNum(String hakNum) {
		this.hakNum = hakNum;
	}
	public int getKor() {
		return kor;
	}
	public void setKor(int kor) {
		this.kor = kor;
	}
	public int getEng() {
		return eng;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public int getMath() {
		return math;
	}
	public void setMath(int math) {
		this.math = math;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public double getAvg() {
		return avg;
	}
	public void setAvg(double avg) {
		this.avg = avg;
	}
	
	public void getStudentScore() {
		System.out.println("학번"+ getHakNum());
		System.out.println("학번"+ getKor());
		System.out.println("학번"+ getEng());
		System.out.println("학번"+ getMath());
		System.out.println("학번"+ getTotal());
		System.out.println("학번"+ getAvg());
	
		
	}
	
}
