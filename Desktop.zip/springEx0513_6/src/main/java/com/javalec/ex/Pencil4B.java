package com.javalec.ex;

public class Pencil4B implements Pencil {

	public void use() {
		System.out.println("Pencil4B");
		System.out.println("Pencil4B 굴기 기능을 가지고 있습니다.");
	}

}
