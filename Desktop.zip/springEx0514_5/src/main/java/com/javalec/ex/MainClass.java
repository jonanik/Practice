package com.javalec.ex;

import javax.swing.AbstractAction;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//annotationApplicationContext ctx=new AnnotationApplication(ConfigCTX.class);를 통해서 student1을 가져올 수 있는거였음
			AbstractApplicationContext ctx=new GenericXmlApplicationContext("classpath:appCTX.xml");
			Student student1=ctx.getBean("student1",Student.class);
			Student student2=ctx.getBean("student2",Student.class);
			student1.get_stuPrint();
			student2.get_stuPrint();
			
	}
}
