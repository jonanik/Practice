package com.javalec.ex;

import java.util.Scanner;

import org.springframework.context.support.AbstractApplicationContext;

import org.springframework.context.support.GenericXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		AbstractApplicationContext ctx=new GenericXmlApplicationContext("classpath:applicationCTX.xml");
		Temperature temperature=ctx.getBean("temperature",Temperature.class);
		System.out.println("나라명:"+temperature.nav);
		System.out.print("현재 기온:");
		temperature.cal_temp();

		Scanner scan=new Scanner(System.in);
		System.out.println("섭씨를 입력하세요.");
		double cc=scan.nextDouble();
		temperature.setTemp(cc);
		
	};

}
