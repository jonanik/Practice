package com.javalec.ex;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

@Configuration
public class AppCTX {

	@Value("${line}")
	private String line;
	@Value("${statn_nm}")
	private String statn_nm;
	@Value("${adres}")
	private String adres;
	@Value("${rdnmadr}")
	private String rdnmadr;
	@Value("${telno}")
	private String telno;
	
	@Bean
	public static PropertySourcesPlaceholderConfigurer property() {
		PropertySourcesPlaceholderConfigurer configurer=new PropertySourcesPlaceholderConfigurer();
		Resource[] location=new Resource[1];
		location[0]=new ClassPathResource("info.properties");
		
		configurer.setLocations(location[0]);
		return configurer;
	}
	
	@Bean
	public Info info() {
		Info info=new Info();
		info.setLine(line);
		info.setStatn_nm(statn_nm);
		info.setAdres(adres);
		info.setRdnmadr(rdnmadr);
		info.setTelno(telno);
		return info;
	}
	
}
