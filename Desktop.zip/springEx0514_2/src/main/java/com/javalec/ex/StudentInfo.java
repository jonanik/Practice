package com.javalec.ex;

public class StudentInfo {

	private Student student;
	
	public StudentInfo() {}
	
	public void setStudent(Student student) {
		this.student = student;
	}

	public StudentInfo(Student student) {
		this.student=student;
	}

	public Student getStudent() {
		return student;
	}
	
}
