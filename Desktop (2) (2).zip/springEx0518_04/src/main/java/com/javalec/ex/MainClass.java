package com.javalec.ex;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext(AppCTX.class);;
		ServerInfo serverInfo=ctx.getBean("serverInfo",ServerInfo.class);
		System.out.println("auth: "+serverInfo.getAuth());
		System.out.println("auth: "+serverInfo.getDriverClassName());
		System.out.println("auth: "+serverInfo.getUrl());
		System.out.println("auth: "+serverInfo.getUsername());
		System.out.println("auth: "+serverInfo.getPassword());
		System.out.println("auth: "+serverInfo.getName());
		System.out.println("auth: "+serverInfo.getType());
		System.out.println("auth: "+serverInfo.getMaxActive());
		System.out.println("auth: "+serverInfo.getMaxWait());
		

	}

}
