package com.javelec.ex;

public interface Service {
	
	String getMessage();

}
