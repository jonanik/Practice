package com.javalec.ex;

import java.util.ArrayList;

public class StuInfo {

	  public StuInfo() {}
	   
	   
	   public StuInfo(ArrayList<Student> list) {
	      this.list = list;
	      
	   }
	   
	   ArrayList<Student> list;

	public ArrayList<Student> getList() {
		return list;
	}


	public void setList(ArrayList<Student> list) {
		this.list = list;
	}

	  
	   
	

}
