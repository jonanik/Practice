package com.javalec.ex;

public class BookLoan {

	private String hakNum;
	private String bookNum;
	private String subject;
	private String category;
	private String loan,reloan,delay;
	public String getHakNum() {
		return hakNum;
	}
	public void setHakNum(String hakNum) {
		this.hakNum = hakNum;
	}
	public String getBookNum() {
		return bookNum;
	}
	public void setBookNum(String bookNum) {
		this.bookNum = bookNum;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getLoan() {
		return loan;
	}
	public void setLoan(String loan) {
		this.loan = loan;
	}
	public String getReloan() {
		return reloan;
	}
	public void setReloan(String reloan) {
		this.reloan = reloan;
	}
	public String getDelay() {
		return delay;
	}
	public void setDelay(String delay) {
		this.delay = delay;
	}
	
	public void getBookLoan() {
		System.out.println("학번"+ getHakNum());
		System.out.println("도서번호"+ getBookNum());
		System.out.println("도서제목"+ getSubject());
		System.out.println("분류"+ getCategory());
		System.out.println("대출일자"+ getLoan());
		System.out.println("반납일자"+ getReloan());
		System.out.println("연체일"+ getDelay());
	}
	
}
