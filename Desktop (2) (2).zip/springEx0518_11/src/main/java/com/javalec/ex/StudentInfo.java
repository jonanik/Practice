package com.javalec.ex;

public class StudentInfo {

	private String hakNum;
	private String name;
	private String major;
	private String address;
	private String phone;
	
	public String getHakNum() {
		return hakNum;
	}
	public void setHakNum(String hakNum) {
		this.hakNum = hakNum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public void getStudentInfo() {
		System.out.println("학번:"+ getHakNum());
		System.out.println("이름:"+ getName());
		System.out.println("전공:"+ getMajor());
		System.out.println("주소:"+ getAddress());
		System.out.println("전화번호:"+ getAddress());
	}
	
}
