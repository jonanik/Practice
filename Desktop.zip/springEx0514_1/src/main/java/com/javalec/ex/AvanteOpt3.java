package com.javalec.ex;

public class AvanteOpt3 implements Avante {

	public void basic() {
		System.out.println("스마트스트림 가솔린 1.6엔진");
		System.out.println("디스크 브레이크");
		
	}
	public void option() {
		System.out.println("인조가죽 도어 센터트림");
		System.out.println("하이패스 시스템+ECM룸미러");
		System.out.println("인포테인먼트 내비 i");
	}
	
}
