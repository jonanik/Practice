package com.javalec.ex;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext(AppCTX.class);
		Info info= ctx.getBean("info",Info.class);
		
		System.out.println("Line: "+info.getLine());
		System.out.println("statn_nm: "+info.getStatn_nm());	
		System.out.println("adres: "+info.getAdres());
		System.out.println("rdnmadr: "+info.getRdnmadr());
		System.out.println("telno: "+info.getTelno());

	}

}
