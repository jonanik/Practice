package com.javalec.ex;

public class Calculator {

	public void cal_temp(double temp) {
		double f= (temp * 1.8) + 32;
		System.out.println("화씨:"+f);
	}
}
