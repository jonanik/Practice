package com.javalec.ex;

public class StuScore {

	public StuScore() {}
	public StuScore(String hakNum,int korScore,int engScore,int mathScore) {
		this.hakNum=hakNum;
		this.korScore=korScore;
		this.engScore=korScore;
		this.mathScore=mathScore;
		this.totalScore=korScore+engScore+mathScore;
		this.scoreAvg=totalScore/3;
	}
	
	String hakNum;
	int korScore;
	int engScore;
	int mathScore;
	int totalScore=korScore+engScore+mathScore;
	double scoreAvg=totalScore/3;
	

	public String getHakNum() {
		return hakNum;
	}
	public void setHakNum(String hakNum) {
		this.hakNum = hakNum;
	}
	public int getKorScore() {
		return korScore;
	}
	public void setKorScore(int korScore) {
		this.korScore = korScore;
	}
	public int getEngScore() {
		return engScore;
	}
	public void setEngScore(int engScore) {
		this.engScore = engScore;
	}
	public int getMathScore() {
		return mathScore;
	}
	public void setMathScore(int mathScore) {
		this.mathScore = mathScore;
	}
	public int getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}
	public double getScoreAvg() {
		return scoreAvg;
	}
	public void setScoreAvg(double scoreAvg) {
		this.scoreAvg = scoreAvg;
	}
	
	
}
