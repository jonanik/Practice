package com.javalec.ex;

import java.util.Scanner;

import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		String config="";
		System.out.println("환경을 선택하세요. 1)window    2)tablet    3)mobile");
		Scanner scan=new Scanner(System.in);
		int num=scan.nextInt();
		switch (num) {
		case 1:
			config="window";
			break;
		case 2:
			config="tablet";
			break;
		case 3:
			config="mobile";
			break;
		default:
			break;
		}
		
		GenericXmlApplicationContext ctx=new GenericXmlApplicationContext();
		ctx.getEnvironment().setActiveProfiles(config);
		ctx.load("appCTX1.xml","appCTX2.xml","appCTX3.xml");
		ctx.refresh();
		Environment environment=ctx.getBean("environment",Environment.class);
		System.out.println("서버 접속 완료");
		System.out.println("브라우저: "+environment.browser);
		System.out.println("접속 IP: "+environment.ip);
		System.out.println("접속방법: "+environment.loginType);
		

	}

}
