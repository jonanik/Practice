package com.javalec.ex;

public class Pencil6BEraser implements Pencil {

	public void use() {
		System.out.println("Pencil6BEraser");
		System.out.println("Pencil6BEraser 굵기 기능과 지우개 기능을 가지고 있습니다.");

	}

}
