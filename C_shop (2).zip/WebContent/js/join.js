/**
 * 
 */

function joinCheck(){
 	var idcheck=(/^(?=.*[0-9])(?=.*[a-z])(?=.*[!@#$%^&*]).{4,15}$/);
 	
 	if(join.mId.value==""){
 		alert("아이디를 입력하세요");
 		return false;
 	}
 	if(!(idcheck.test(join.mId.value))){
 		alert("아이디는 4~15자리 내에서 영문,숫자,특수기호(!@#$%^&*)를 적어도 한글자씩 사용하셔야합니다.");
 		join.mId.value="";
 		join.mId.focus();
 		return false;
 	}

 	return join.submit();
 	
 }