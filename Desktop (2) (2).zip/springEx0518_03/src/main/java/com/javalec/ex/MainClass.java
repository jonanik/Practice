package com.javalec.ex;

import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
	GenericXmlApplicationContext ctx=new GenericXmlApplicationContext();
	ctx.load("appCTX.xml");
	ctx.refresh();
	AdminConnection adminConnection=ctx.getBean("adminConnection",AdminConnection.class);
	System.out.println("Auth: "+adminConnection.getAuth());
	System.out.println("DriverClassName: "+adminConnection.getDriverClassName());
	System.out.println("Url: "+adminConnection.getUrl());
	System.out.println("Usernam: "+adminConnection.getUsername());
	System.out.println("Password: "+adminConnection.getPassword());
	System.out.println("Name: "+adminConnection.getName());
	System.out.println("Type: "+adminConnection.getType());
	System.out.println("MaxActive: "+adminConnection.getMaxActive());
	System.out.println("MaxWait: "+adminConnection.getMaxWait());

	ctx.close();
	}

}
