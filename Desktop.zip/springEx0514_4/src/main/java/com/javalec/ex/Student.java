package com.javalec.ex;

public class Student {

	Student(){}
	
	Student(String hakNum,String hakName,int korScore,int engScore,int mathScore ){
		this.hakNum=hakNum;
		this.hakName=hakName;
		this.korScore=korScore;
		this.engScore=engScore;
		this.mathScore=mathScore;
		this.totalScore=korScore+engScore+mathScore;
		this.scoreAvg=totalScore/3;
	}
	
	String hakNum;
	String hakName;
	int korScore;
	int engScore;
	int mathScore;
	int totalScore;
	double scoreAvg;
	public String getHakNum() {
		return hakNum;
	}
	public void setHakNum(String hakNum) {
		this.hakNum = hakNum;
	}
	public String getHakName() {
		return hakName;
	}
	public void setHakName(String hakName) {
		this.hakName = hakName;
	}
	public int getKorScore() {
		return korScore;
	}
	public void setKorScore(int korScore) {
		this.korScore = korScore;
	}
	public int getEngScore() {
		return engScore;
	}
	public void setEngScore(int engScore) {
		this.engScore = engScore;
	}
	public int getMathScore() {
		return mathScore;
	}
	public void setMathScore(int mathScore) {
		this.mathScore = mathScore;
	}
	public int getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}
	public double getScoreAvg() {
		return scoreAvg;
	}
	public void setScoreAvg(double scoreAvg) {
		this.scoreAvg = scoreAvg;
	}
	
	public void getScore() {
		System.out.println("학번:"+hakNum);
		System.out.println("학생이름:"+hakName);
		System.out.println("국어성적:"+korScore);
		System.out.println("영어성적:"+engScore);
		System.out.println("수학성적:"+mathScore);
		System.out.println("합계:"+totalScore);
		System.out.println("평균:"+scoreAvg);
		System.out.println("--------------------");
	}
	
}
